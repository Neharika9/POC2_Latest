﻿using System.Collections.Generic;

namespace EmployeeTracker.Repositories
{
    //The Generic Interface Repository for Performing Read/Add/Delete operations
    public interface IEmployeeDetailRepository<TEnt, in TPk> where TEnt : class
    {
        IEnumerable<TEnt> Get();
        TEnt Get(TPk id);
        void Add(TEnt entity);
        void Remove(TEnt entity);
    }
}