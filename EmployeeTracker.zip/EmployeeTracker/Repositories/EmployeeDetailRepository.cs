﻿using Microsoft.Practices.Unity;
using EmployeeTracker.Repositories;
using EmployeeTracker.Models;
using System.Collections.Generic;
using System.Linq;
using Unity.Attributes;

namespace EmployeeTracker.Repositories
{
    //The EmployeeInfo Repository Class. This is used to 
    //Isolate the EntitiFtamework based Data Access Layer from
    //the MVC Controller class
    public class EmployeeDetailRepository : IEmployeeDetailRepository<EmployeeDetail, int>
    {
        [Dependency]
        public EmployeeTrackerEntities context { get; set; }

        public IEnumerable<EmployeeDetail> Get()
        {
            return context.EmployeeDetails.ToList();
        }

        public EmployeeDetail Get(int id)
        {
            return context.EmployeeDetails.Find(id);
        }

        public void Add(EmployeeDetail entity)
        {
            context.EmployeeDetails.Add(entity);
            context.SaveChanges();
        }

        public void Remove(EmployeeDetail entity)
        {
            var obj = context.EmployeeDetails.Find(entity.EmpId);
            context.EmployeeDetails.Remove(obj);
            context.SaveChanges();
        }
    }
}