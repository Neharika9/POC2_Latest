﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EmployeeTracker.BusinessLayer;
using EmployeeTracker.DTO;

namespace EmployeeTracker.Controllers
{
    public class EmployeeController : ApiController
    {
        public EmployeeService _employeeService;
        public EmployeeController()
        {
            _employeeService = new EmployeeService();
        }

        // GET api/order
        public HttpResponseMessage Get()
        {
            var emp = _employeeService.Get();
            if (emp != null)
                return Request.CreateResponse(HttpStatusCode.OK, emp);
            else return Request.CreateErrorResponse(HttpStatusCode.NotFound, "No orders found");
        }

        // POST: api/Employees
        public IHttpActionResult PostEmployee(EmployeeDto employee)
        {
            ///var Emp = _employeeService.Get(employee.EmpId);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            
           // db.Employees.Add(employee);

            //try
            //{

              //  await db.SaveChangesAsync();

            //}
            ////catch (DbUpdateException)
            ////{
            ////    if (EmployeeExists(employee.Id))
            ////    {
            ////        return Conflict();
            ////    }
            ////    else
            ////    {
            ////        throw;
            ////    }
            ////}

            return CreatedAtRoute("DefaultApi", new { }, employee);
        }


    }
}
